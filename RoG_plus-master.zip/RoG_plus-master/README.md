# RoG+: A Fast Scale-Aware Filter via Relativity-of-Gaussian
